d3.csv("data/tv_2025_03_13.csv").then(rawData => {
  console.log("Raw row sample:", rawData[0]);
  console.log("Keys in row:", Object.keys(rawData[0]));

  const data = rawData.map(d => ({
    brand: d["Brand"]?.trim() || "Unknown",
    energy: parseFloat(d["Energy"]?.trim()) || 0
  }));

  console.log("✅ Cleaned Data Sample:", data.slice(0, 5));

  const svg = d3.select(".responsive-svg-container")
    .append("svg")
    .attr("viewBox", "0 0 1200 1600")
    .style("border", "1px solid black");

  const barHeight = 30;
  const barSpacing = 15;

  data.sort((a, b) => b.energy - a.energy);

  svg.selectAll("rect")
    .data(data)
    .join("rect")
    .attr("x", 100)
    .attr("y", (d, i) => i * (barHeight + barSpacing))
    .attr("width", d => d.energy * 0.5) // smaller scale for large values
    .attr("height", barHeight)
    .attr("fill", "steelblue");

  svg.selectAll("text")
    .data(data)
    .join("text")
    .text(d => `${d.brand} (${d.energy}W)`)
    .attr("x", 10)
    .attr("y", (d, i) => i * (barHeight + barSpacing) + barHeight / 1.5)
    .attr("font-size", "13px")
    .attr("fill", "#333");
});
